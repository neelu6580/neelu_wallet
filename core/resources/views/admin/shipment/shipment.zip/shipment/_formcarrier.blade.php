<div class="form-group">
    <label>Status</label>
    <select class="form-control makeSlug" name="status">
        <option value="1">Active</option>
        <option value="0">Inctive</option>
    </select>
  <div class="help-block with-errors"></div>
</div>