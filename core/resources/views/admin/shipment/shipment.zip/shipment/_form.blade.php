<div class="form-group">
  {!! Form::label('margin', trans('Margin').'*') !!}
  {!! Form::text('margin', null, ['class' => 'form-control makeSlug', 'placeholder' => trans('Margin'), 'required']) !!}
  <div class="help-block with-errors"></div>
</div>